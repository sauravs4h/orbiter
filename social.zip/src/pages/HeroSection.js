import TopNavigation from "../components/TopNavigation";
import "./HeroSection.css";

const HeroSection = () => {
  return (
    <div className="hero-section">
      <div className="welcome-to-orbiter">Welcome to Orbiter</div>
      <div className="connect-with-parent">
        <div className="connect-with">Connect with</div>
        <div className="component-5">
          <div className="mentors">Mentors</div>
          <div className="investors">Investors</div>
          <div className="entreprenuers">Entreprenuers</div>
          <div className="startups">Startups</div>
          <div className="incubators">Incubators</div>
          <div className="b-school">B-School</div>
          <div className="companies">Companies</div>
          <div className="organization">Organization</div>
          <div className="virtual-team">Virtual Team</div>
        </div>
      </div>
      <div className="funded-by-rajasthan-goverment-parent">
        <div className="funded-by-rajasthan-container">
          <span>{`Funded by `}</span>
          <b>Rajasthan Goverment</b>
        </div>
        <img className="frame-child" alt="" src="/line-23.svg" />
        <div className="funded-by-rajasthan-container">
          <span>{`Incubated in `}</span>
          <b>IIT, Mandi</b>
        </div>
      </div>
      <img className="hero-image-icon" alt="" src="/hero-image.svg" />
      <img
        className="calender-dynamic-color-icon"
        alt=""
        src="/calenderdynamiccolor@2x.png"
      />
      <TopNavigation />
    </div>
  );
};

export default HeroSection;
